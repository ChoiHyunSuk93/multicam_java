package 마무리문제;

public class Truck extends Car{
	
	int weight;
	
	public void trunk() {
		System.out.println("짐을 싣습니다.");
	}
}
