package 마무리문제;

public class Car {
	String color;
	
	public void drive() {
		System.out.println("도로를 달립니다.");
	}
}
